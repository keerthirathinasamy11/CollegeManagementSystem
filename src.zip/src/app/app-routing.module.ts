import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './pages/Student/login/login.component';
import { StudentSignupComponent } from './pages/Student/student-signup/student-signup.component';
import { StudentService } from './student.service';
import { StudentComponent } from './student/student.component';
import { AboutComponent } from './about/about.component';
import { AdminloginComponent } from './admin/adminlogin/adminlogin.component';
import { FacultyloginComponent } from './admin/facultylogin/facultylogin.component';
import { HomeComponent } from './home/home.component';
import { AdminDashboardComponent } from './admin/admin-dashboard/admin-dashboard.component';

import { CoursesComponent } from './courses/courses.component';
import { AttendanceService } from './attendance.service';
import { FacultySignupComponent } from './faculty/faculty-signup/faculty-signup.component';
import { FacultyService } from './faculty.service';
import { FacultyDashboardComponent } from './faculty/faculty-dashboard/faculty-dashboard.component';
import { ExamComponent } from './exam/exam.component';
import { FeesComponent } from './fees/fees.component';
import { ShowstudentComponent } from './showstudent/showstudent.component';
import { ShowfacultyComponent } from './showfaculty/showfaculty.component';
import { CollegeComponent } from './college/college.component';

const routes: Routes = [
  
  { path: '', redirectTo: '/home', pathMatch: 'full' }, 
  { path: 'home', component: HomeComponent },
  { path: 'student-signup', component: StudentSignupComponent },
  { path:'admin-dashboard', component :AdminDashboardComponent},
  { path: 'login', component: LoginComponent },
  { path: 'student', component: StudentComponent },
  { path: 'about', component: AboutComponent },
  { path: 'adminlogin', component: AdminloginComponent },
  { path: 'facultylogin', component: FacultyloginComponent },
  { path:'studentService', component:StudentService},
  { path :'attendance' ,component :AttendanceService},
  { path :'attendanceService',component :AttendanceService},
  { path :'showstudent',component:ShowstudentComponent},
  { path :'showsfaculty',component:ShowfacultyComponent},
  { path :'courses',component:CoursesComponent},
  { path :'faculty-signup' ,component :FacultySignupComponent},
  { path : 'facultyservice',component: FacultyService},
  { path :'faculty-dashboard',component:FacultyDashboardComponent},
  { path :'fees', component:FeesComponent},
  { path : 'exam',component:ExamComponent},
  { path :'College', component :CollegeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
