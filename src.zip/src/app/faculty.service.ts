import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FacultyService {

  private apiUrl = 'http://localhost:8080/faculty'; // Replace with your Spring Boot backend URL

  constructor(private http: HttpClient) {}

  addFaculty(faculty: any): Observable<any> {
    const addFacultyUrl = `${this.apiUrl}/saveFaculty`; // Replace with your API endpoint URL
    return this.http.post(addFacultyUrl, faculty);
  }

  getFacultyById(id: number): Observable<any> {
    const url = `${this.apiUrl}/getfaculty/${id}`;
    return this.http.get(url);
  }

  getAllFaculties(): Observable<any> {
    return this.http.get(`${this.apiUrl}/getfaculty`);
  }

  updateFaculty(faculty: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/updateFaculty`, faculty);
  }

  deleteFaculty(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/deletefaculty/${id}`);
  }

}
