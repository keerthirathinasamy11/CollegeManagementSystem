import { Component, OnInit } from '@angular/core';
import { StudentService } from 'src/app/student.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-student-signup',
  templateUrl: './student-signup.component.html',
  styleUrls: ['./student-signup.component.css']
})
export class StudentSignupComponent implements OnInit{

  ngOnInit(): void {
  }

  constructor(
    private studentService:StudentService,private router:Router
  ) {}

  user_records:any[]=[];

  public user={
    firstname:'',
    lastname:'',
    gender:'',
    studentemail:'',
    password:'',
    course:''

  };
  
  submitForm(){
   
      console.log(this.user);
    
      if (
        this.user.firstname === '' || this.user.firstname === null ||
        this.user.lastname === '' || this.user.lastname === null ||
        this.user.gender === '' || this.user.gender === null ||
        this.user.studentemail === '' || this.user.studentemail === null ||
        this.user.password === '' || this.user.password === null ||
        this.user.course === '' || this.user.course === null
      ) {
        alert('All fields are required');
        return; 
      }
    
      this.user_records = JSON.parse(localStorage.getItem('users') || '[]');
    
      if (this.user_records.some((v) => v.studentemail === this.user.studentemail)) {
        alert("Duplicate Data");
      } else {
        this.user_records.push(this.user);
        localStorage.setItem("users", JSON.stringify(this.user_records));
        alert("Hi " + this.user.firstname + ", You are successfully registered");
      }
    
      this.studentService.addStudent(this.user).subscribe(
        (data: any) => {
          // success
          console.log(data);
        },
        (error: any) => {
          console.log(error);
          alert('Error');
        }
      );
    }
    
  }
  

