import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FacultyService } from 'src/app/faculty.service';

@Component({
  selector: 'app-faculty-signup',
  templateUrl: './faculty-signup.component.html',
  styleUrls: ['./faculty-signup.component.css']
})
export class FacultySignupComponent implements OnInit{

  ngOnInit(): void {
  }

  constructor(
    private facultyservice:FacultyService ,private router:Router
  ) {}

  user_records:any[]=[];


 
  public faculty={
    FullName:'',
    gender:'',
    FacultyEmail:'',
    password:'',
    designation:'',
    department:'',
    contact:'',
    address:'',

  };
  
  submitForm(){
    {
      console.log(this.faculty)
      if(this.faculty.FullName=='' ||this.faculty.FullName==null)
      {
        alert('Name is required');
        
      }
      if(this.faculty.gender=='' ||this.faculty.gender==null)
      {
        alert('Gender is required');
        
      }
      if(this.faculty.FacultyEmail=='' ||this.faculty.FacultyEmail==null)
      {
        alert('Email is required');
        
      }
      if(this.faculty.designation=='' ||this.faculty.designation==null)
      {
        alert('Designation is required');
        
      }
      if(this.faculty.password=='' ||this.faculty.password==null)
      {
        alert('Password is required');        
      }
      if(this.faculty.department=='' ||this.faculty.department==null)
      {
        alert('department is required');
      }
      if(this.faculty.contact=='' ||this.faculty.contact==null)
      {
        alert('contact is required');
      }
      if(this.faculty.address=='' ||this.faculty.address==null)
      {
        alert('address is required');
      
      }
  
      //adduser:userservice
      this.facultyservice.addFaculty(this.faculty).subscribe(
      (data:any) => {
        console.log(data);
        alert('success');
           },
      (error) =>
      {
        console.log(error);
        alert('error');        
      }
      );
      

    this.user_records=JSON.parse(localStorage.getItem('users')||'{}');
    if(this.user_records.some((v)=>{
      return v.FacultyEmail==this.faculty.FacultyEmail
    })){
      alert("Duplicate Data");
    }
    else{
      this.user_records.push(this.faculty)
      localStorage.setItem("users",JSON.stringify(this.user_records));
      alert("Hi"+" "+this.faculty.FullName+" "+"You are successfully registered");
    }
  }
    
  }

}
