import { Component ,OnInit} from '@angular/core';

@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})
export class CoursesComponent {

  courses: any[] = [
    {
      title: 'Bachelor of Science (B.Sc) in Mathematics',
      description: 'Explore advanced concepts in mathematics and statistics.',
      duration: '3 years'
    },
    {
      title: 'Bachelor of Science (B.Sc) in Physics',
      description: 'Dive into the world of physics and its applications.',
      duration: '3 years'
    },
    {
      title: 'Introduction to Computer Science',
      description: 'Learn the basics of programming and algorithms.',
      duration: '3 years'
    },
    {
      title: 'Web Development Fundamentals',
      description: 'Build interactive websites using HTML, CSS, and JavaScript.',
      duration: '3 years'
    },
    {
      title: 'Database Design and Management',
      description: 'Explore database concepts and SQL programming.',
      duration: '3 years'
    },
      {
        title: 'Bachelor of Commerce (B.Com)',
        description: 'Study the fundamentals of commerce and business management.',
        duration: '3 years'
      },
      {
        title: 'Bachelor of Computer Applications (BCA)',
        description: 'Learn programming and software development.',
        duration: '3 years'
      },
  ];

  constructor() { }

  ngOnInit(): void {
  }


}
