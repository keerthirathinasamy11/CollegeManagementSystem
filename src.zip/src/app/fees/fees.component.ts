import { Component } from '@angular/core';

interface FeeDetail {
  id: number;
  description: string;
  amount: number;
  status: string;
}

const FAKE_FEES: FeeDetail[] = [
  { id: 1, description: 'Tuition Fee', amount: 1000, status: 'Paid' },
  { id: 2, description: 'Library Fee', amount: 50, status: 'Paid' },
  { id: 3, description: 'Exam Fee', amount: 200, status: 'Unpaid' },
 
];

@Component({
  selector: 'app-fees',
  templateUrl: './fees.component.html',
  styleUrls: ['./fees.component.css']
})

export class FeesComponent {
  fees: FeeDetail[] = FAKE_FEES;
}
