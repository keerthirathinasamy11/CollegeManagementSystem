import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  
  private apiUrl = 'http://localhost:8080/student'; 

  constructor(private http: HttpClient) {}

   addStudent(student: any): Observable<any> {
    const addStudentUrl = `${this.apiUrl}/saveStudent`; 
    return this.http.post(addStudentUrl, student);
  }
  getStudentById(id: number) {
    const url = `${this.apiUrl}/getstudent/${id}`;
    return this.http.get(url);
  }

  public getStudent(){
    return this.http.get('http://localhost:8080/student/getallstudents');
  }

  
  getAllStudents(): Observable<any> {
    return this.http.get(`${this.apiUrl}/getallstudents`);
  }
  
  public updateStudent(data:any){
    return this.http.put('http://localhost:8080/student/updatestudents',data);
  }

  public deleteStudent(id:number){
    return this.http.delete('http://localhost:8080/student/deletestudent/'+id);
  }
}
