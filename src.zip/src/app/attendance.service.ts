import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AttendanceService {

  constructor(private http:HttpClient) { }

  public addAttendance(data:any){
    return this.http.post('http://localhost:8080/attendance/',data);
  }

  public getAttendance(){
    return this.http.get('http://localhost:8080/attendance/get');
  }

  public deleteAttendance(id:number){
    return this.http.delete('http://localhost:8080/attendance/'+id);
  }

  public updateAttendance(data:any){
     return this.http.put('http://localhost:8080/attendance/update',data);
  }
}
