import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-facultylogin',
  templateUrl: './facultylogin.component.html',
  styleUrls: ['./facultylogin.component.css']
})
export class FacultyloginComponent {

  constructor(private router:Router){

  }

  user_records:any[]=[];
  
  user={
    FacultyEmail:'',
    password:''
  }

  doLogin(values:any){
    this.user_records=JSON.parse(localStorage.getItem("users")||'{}');
    if(this.user_records.some((v)=>{
      return v.FacultyEmail==this.user.FacultyEmail && v.password==this.user.password
    })){
      alert("Login Successful");
      this.router.navigate(['/faculty-dashboard']);
    }
    else{
      alert("Login Failed");
    }
  }

}
