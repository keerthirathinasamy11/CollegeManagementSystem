
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {

  ngOnInit(): void {

  }
  constructor(private router: Router) { }

  public user = {
    firstname: '',
    lastname: '',
    gender: '',
    studentemail: '',
    password: '',
    course: ''

  };

  public adminLogin = {
    username: '',
    password: ''
  }

  login() {
    console.log(this.adminLogin)
    if (this.adminLogin.username == '' || this.adminLogin.username == null) {
      alert('user is required');

      // return;
    }
    if (this.adminLogin.password == '' || this.adminLogin.password == null) {
      alert('password is required');

      //return;
    }
    if (this.adminLogin.username === 'admin' || this.adminLogin.password == 'admin123') {
      this.router.navigate(['/admin-dashboard']);
    }
    else {
      alert('Username or Password is Not Valid')
    }
    


  }
}
