import { Component } from '@angular/core';

@Component({
  selector: 'app-showfaculty',
  templateUrl: './showfaculty.component.html',
  styleUrls: ['./showfaculty.component.css']
})
export class ShowfacultyComponent {

}
