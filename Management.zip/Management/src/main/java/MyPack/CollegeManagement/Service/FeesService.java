package MyPack.CollegeManagement.Service;

import java.util.List;

import MyPack.CollegeManagement.Model.Fees;


public interface FeesService 
{
	public Fees saveFees(Fees fee);
	public Fees updateFees(Fees fee);
	public void deleteFees(Long id);
    public List<Fees> findallFees();
    
    public Fees getFees(Long id);

}
