package MyPack.CollegeManagement.Service;

import java.util.List;

import MyPack.CollegeManagement.Model.Exam;

public interface ExamService 
{
	//to save new exam
			public Exam saveExam(Exam exam);
			
			//to update exam
			public Exam updateExam(Exam exam);
			
			//to fetch all exam from database
			
			public List<Exam> findallExam();
			
			//to delete exam
			public void deleteExam(long ExamId);

}
