package MyPack.CollegeManagement.Service;

import java.util.List;

import MyPack.CollegeManagement.Model.Attendance;


public interface AttendanceService 
{
	public Attendance saveAttendance(Attendance attendance);
	public Attendance updateAttendance(Attendance attendance);
	public void deleteAttendance(Long id);
    public List<Attendance> findallAttendances();

}
