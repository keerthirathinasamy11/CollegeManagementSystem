package MyPack.CollegeManagement.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import MyPack.CollegeManagement.Model.Student;
import MyPack.CollegeManagement.Repository.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService
{

	@Autowired
    private StudentRepository studentRepository;

	@Override
	public Student saveStudent(Student student) {
		// TODO Auto-generated method stub
		return studentRepository.save(student);
	}

	@Override
	public Student updateStudent(Student student) {
		// TODO Auto-generated method stub
		return studentRepository.save(student);
	}

	@Override
	public List<Student> findallStudents() {
		// TODO Auto-generated method stub
		return studentRepository.findAll();
	}

	@Override
	public void deleteStudent(long StudentId) 
	{
		studentRepository.deleteById(StudentId);;
		// TODO Auto-generated method stub
		
	}

	public Student findStudentById(long id) {
       Optional<Student> optionalStudent = studentRepository.findById(id);
        
        if (optionalStudent.isEmpty()) {
            return null; 
        }

        return optionalStudent.get();
    }
		

}
