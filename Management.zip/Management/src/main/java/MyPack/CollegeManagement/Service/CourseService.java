package MyPack.CollegeManagement.Service;

import java.util.List;

import MyPack.CollegeManagement.Model.Course;

public interface CourseService {
	//to save new Course
		public Course saveCourse(Course course);
		
		//to update Course
		public Course updateCourse(Course Course);
		
		//to fetch all Course from database
		
		public List<Course> findallCourses();
		
		//to delete Course
		public void deleteCourse(long CourseId);
}
