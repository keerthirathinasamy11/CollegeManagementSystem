package MyPack.CollegeManagement.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import MyPack.CollegeManagement.Model.Fees;
import MyPack.CollegeManagement.Repository.FeesRepository;

@Service
public class FeesServiceImpl implements FeesService
{

	@Autowired
	private FeesRepository feesRepository;
	@Override
	public Fees saveFees(Fees fee) 
	{
		
		return this.feesRepository.save(fee);
	}

	@Override
	public Fees updateFees(Fees fee)
	{
		
		return this.feesRepository.save(fee);
	}

	@Override
	public void deleteFees(Long id)
	{
		this.feesRepository.deleteById(id);
		
	}

	@Override
	public List<Fees> findallFees() 
	{
		
		return this.feesRepository.findAll();
	}

	@Override
	public Fees getFees(Long id) {
		
		return this.feesRepository.findById(id).get();
	}

}
