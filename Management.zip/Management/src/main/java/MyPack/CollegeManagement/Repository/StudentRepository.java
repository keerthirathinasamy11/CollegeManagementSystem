package MyPack.CollegeManagement.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import MyPack.CollegeManagement.Model.Student;

public interface StudentRepository extends JpaRepository<Student,Long>{

}
