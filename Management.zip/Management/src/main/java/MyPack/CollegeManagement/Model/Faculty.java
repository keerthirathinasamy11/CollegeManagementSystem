package MyPack.CollegeManagement.Model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="faculty")
public class Faculty
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	
	@Column(nullable=false)
	private Long Id;
	private String FullName;
	private String Gender;
	private String FacultyEmail;
	private String Password;
	private String Designation;
	private String Department;
	private String contact;
	private String Address;
	
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY,mappedBy="Faculty")
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	
	public String getFullName() 
	{
		return FullName;
	}
	
	public void setFullName(String fullName) 
	{
		FullName = fullName;
	}
	public String getGender() 
	{
		return Gender;
	}
	public void setGender(String gender) 
	{
		Gender = gender;
	}
	public String getFacultyEmail() 
	{
		return FacultyEmail;
	}
	public void setFacultyEmail(String facultyEmail) 
	{
		FacultyEmail = facultyEmail;
	}
	public String getPassword() 
	{
		return Password;
	}
	public void setPassword(String password) 
	{
		Password = password;
	}
	public String getDesignation() 
	{
		return Designation;
	}
	public void setDesignation(String designation) 
	{
		Designation = designation;
	}
	public String getDepartment() 
	{
		return Department;
	}
	public void setDepartment(String department) 
	{
		Department = department;
	}
	public String getContact() 
	{
		return contact;
	}
	public void setContact(String contact) 
	{
		this.contact = contact;
	}
	public String getAddress() 
	{
		return Address;
	}
	public void setAddress(String address) 
	{
		Address = address;
	}
	
	public Faculty(Long id, String fullName, String gender, String facultyEmail, String password, String designation,
			String department, String contact, String address) {
		super();
		Id = id;
		FullName = fullName;
		Gender = gender;
		FacultyEmail = facultyEmail;
		Password = password;
		Designation = designation;
		Department = department;
		this.contact = contact;
		Address = address;
	}
	public Faculty() 
	{
		super();
		// TODO Auto-generated constructor stub
	}
	
}

	
	
	
	
	
	
	
	
	




