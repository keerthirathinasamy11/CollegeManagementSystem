package MyPack.CollegeManagement.Model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="Attendance")
public class Attendance 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long Id;
	private String Studname;
	private Long Studentid;
	private String Dept;
	private String Year;
	private String Month;
	private int Totaldays;
	private int NoOfdayspresent;
	private int NoOfdaysabsent;
	
	@OneToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY,mappedBy = "Attendance")
	
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	public String getStudname() {
		return Studname;
	}
	public void setStudname(String studname) {
		Studname = studname;
	}
	public Long getStudentid() {
		return Studentid;
	}
	public void setStudentid(Long studentid) {
		Studentid = studentid;
	}
	public String getDept() {
		return Dept;
	}
	public void setDept(String dept) {
		Dept = dept;
	}
	public String getYear() {
		return Year;
	}
	public void setYear(String year) {
		Year = year;
	}
	public String getMonth() {
		return Month;
	}
	public void setMonth(String month) {
		Month = month;
	}
	public int getTotaldays() {
		return Totaldays;
	}
	public void setTotaldays(int totaldays) {
		Totaldays = totaldays;
	}
	public int getNoOfdayspresent() {
		return NoOfdayspresent;
	}
	public void setNoOfdayspresent(int noOfdayspresent) {
		NoOfdayspresent = noOfdayspresent;
	}
	public int getNoOfdaysabsent() {
		return NoOfdaysabsent;
	}
	public void setNoOfdaysabsent(int noOfdaysabsent) {
		NoOfdaysabsent = noOfdaysabsent;
	}
	public Attendance(Long id, String studname, Long studentid, String dept, String year, String month, int totaldays,
			int noOfdayspresent, int noOfdaysabsent) {
		super();
		Id = id;
		Studname = studname;
		Studentid = studentid;
		Dept = dept;
		Year = year;
		Month = month;
		Totaldays = totaldays;
		NoOfdayspresent = noOfdayspresent;
		NoOfdaysabsent = noOfdaysabsent;
	}
	public Attendance() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	

}
