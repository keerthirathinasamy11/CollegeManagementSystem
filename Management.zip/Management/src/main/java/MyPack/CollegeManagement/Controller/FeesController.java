package MyPack.CollegeManagement.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import MyPack.CollegeManagement.Model.Fees;

import MyPack.CollegeManagement.Service.FeesService;


@RestController
@RequestMapping("/fees")
@CrossOrigin(allowedHeaders = "*", origins  ="*")
public class FeesController 
{
	@Autowired
	private FeesService feesService;
	
	@PostMapping("/")
	public Fees saveFees(@RequestBody Fees fee)
	{
		return this.feesService.saveFees(fee);
	}
	@GetMapping("/get")
	public List<Fees> findallFees()
	{
		return this.feesService.findallFees();
	}
	
	
	@DeleteMapping("/{id}")
	public void deleteFees(@PathVariable("id") Long id)
	{
		this.feesService.deleteFees(id);
		System.out.println("records deleted successfully");
	}
	@PutMapping("/update")
	public Fees updateFees(@RequestBody Fees fee)
	{
		return this.feesService.updateFees(fee);
	}
	
	@GetMapping("/get/{id}")
	public Fees getById(@PathVariable("id") Long id)
	{
		return this.feesService.getFees(id);
	}

}
